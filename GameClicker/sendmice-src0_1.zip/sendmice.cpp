/*
	Copyright 2007 Massimo Piceni
	
	This file is part of SendMice.

	SendMice is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	SendMice is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with SendMice; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <windows.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <dos.h>

using namespace std;

int GetNextPar (char*, int*);
void RaiseError (int);
char *FtoStr(int);
bool Accepted(char*);

int main(int argc, char **argv, char **envp)
{
	int i = 0;
	char sUName[100];
	sUName[0] = 0;
	do
	{
		if (!strncmp (envp[i],"USERNAME=", 9))
			strcpy (sUName,envp[i]+9);
	} while (envp[++i] != '\0');
	int unflag = 0;
	if (sUName[0] == 0)
	{
		strcpy (sUName,"DEFAULT");
		unflag = 1;
	}
	strcat (sUName,".ACP");
	i = 0;
	cout << "SendMice v.0.1, Copyright 2007 Massimo Piceni,  Licensed under the GNU GPL.\n";
	cout << "SendMice comes with ABSOLUTELY NO WARRANTY;     see README.TXT for details.\n";
	cout << "This is free software, and you are welcome to redistribute it under certain\n";
	cout << "conditions; see LICENSE.TXT for details.\n\n";
	if (!Accepted(sUName))
	{
		char s[100];
		cout << "ATTENTION !!\n------------\n";
		cout << "Misuse of this program  may lead to  DATA CORRUPTION  or  DELETION !!\n";
		cout << "In no case the author may be held responsible  for any problem caused\n";
		cout << "by the use of this  program,  even if is due  to the  program itself.\n";
		cout << "You're the sole responsible of usage of the program and its effects !\n";
		if (unflag)
		{
			cout << "You're also  responsible  of other people's usage  of program on this\n";
			cout << "computer. To accept the above responsibility, type ACCEPT (uppercase)\n";
		}
		else
		{
			cout << "You're also responsible of other people's usage of program under your\n";
			cout << "account.  To accept the above responsibility, type ACCEPT (uppercase)\n";
		}
		cout << "followed by the RETURN key. Otherwise type EXIT  to leave the program\n";
		cin >> s;
		if (!strcmp(s, "ACCEPT"))
		{
			struct date d;
			struct time t;
			fstream fin;
			getdate (&d);
			gettime (&t);
			fin.open(sUName,ios::out);
			fin << "ACCEPTED CONDITIONS BY " << sUName << " ON ";
			fin << (int)d.da_mon << "/" << (int)d.da_day << "/" << (int)d.da_year;
			fin << " " << (int)t.ti_hour << ":" << (int)t.ti_min << "." << (int)t.ti_sec << "\n";
			fin.close();
		}
		else
			RaiseError(31);
	}
    if (argc != 2)
	{
		cerr << "Usage: SENDMICE <mice string>\n\n";
		cerr << "where <mice string> = string made of combinations the following:\n";
		cerr << "l          = Left Button Click\n";
		cerr << "r          = Right Button Click\n";
		cerr << "L          = Left Button DoubleClick (eq. to lP100l)\n";
		cerr << "R          = Right Button DoubleClick (eq. to rP100r)\n";
		cerr << "Pn         = Pause for n milliseconds\n";
		cerr << "mx,y       = move x,y pixel relative to pointer position\n";
		cerr << "Mx,y       = move to absolute x,y posizion on screen\n";
		cerr << "sx,y;w,h   = move x,y pixel and select a w*h rectangle (or drag to x+w,y+h)\n";
		cerr << "Sx,y;w,h   = move to absolute x,y & select a w*h rectangle (or drag to x+w,y+h)\n";
		cerr << "Sx,y:x2,y2 = move to absolute x,y and select till (or drag to) absolute x2,y2\n";
		cerr << "wn         = move the wheel n steps (>0 forward, <0 backward)\n";
		cerr << "W          = click the wheel\n";
		cerr << "D          = show extended debug informations (developers use)\n";
/*		cerr << "Examples:\n\n";
		cerr << "SENDMICE M100,50L\n";
		cerr << "double click on position (100,50)\n\n";
		cerr << "SENDMICE rm0,10l\n";
		cerr << "right click, move 10px down and left click\n\n";
		cerr << "SENDMICE w-3P2000W\n";
		cerr << "rotate wheel 3 steps backward, wait 2 secs and click it\n"; */
		RaiseError(10);
	}
	else
	{
		float vscreen_x, vscreen_y;
		int j, b = 1, dbg = 0, pp = 0;
		INPUT *input = new INPUT[100];
		unsigned int blocks[100][2];
		
		for (j = 0; j < 100; j++)
		{
			input[j].type = INPUT_MOUSE;
			input[j].mi.time = 0;
			input[j].mi.mouseData = 0;
			input[j].mi.dx = 0;
			input[j].mi.dy = 0;
			blocks[j][0] = 0;
		}
		j = 0;
		
		vscreen_x = 65535 / GetSystemMetrics(SM_CXVIRTUALSCREEN);
		vscreen_y = 65535 / GetSystemMetrics(SM_CYVIRTUALSCREEN);
		
		while (argv[1][i] != 0)
		{
			switch (argv[1][i])
			{
			case 'l':
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTUP;
				i++;
				break;
			case 'r':
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTUP;
				i++;
				break;
			case 'L':
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTUP;
				blocks[b][1] = 100;
				blocks[b++][0] = j;
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_LEFTUP;
				i++;
				break;
			case 'R':
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTUP;
				blocks[b][1] = 100;
				blocks[b++][0] = j;
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_RIGHTUP;
				i++;
				break;
			case 'P':
				if (j > 0)
				{
					blocks[b][1] = GetNextPar(argv[1],&i);
					blocks[b++][0] = j;
				}
				else
					pp = GetNextPar(argv[1],&i);
				break;
			case 'm':
				input[j].mi.dx = GetNextPar(argv[1],&i);
				if (argv[1][i] == ',')
				{
					input[j].mi.dy = GetNextPar(argv[1],&i);
					input[j++].mi.dwFlags = MOUSEEVENTF_MOVE;
				}
				else
					RaiseError(12);
				break;
			case 'M':
				input[j].mi.dx = (int)(GetNextPar(argv[1],&i) * vscreen_x);
				if (argv[1][i] == ',')
				{
					input[j].mi.dy = (int)(GetNextPar(argv[1],&i) * vscreen_y);
					input[j++].mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK;
				}
				else
					RaiseError(13);
				break;
			case 's':
				input[j].mi.dx = GetNextPar(argv[1],&i);
				if (argv[1][i] == ',')
				{
					input[j].mi.dy = GetNextPar(argv[1],&i);
					if (argv[1][i] == ';')
					{
						input[j++].mi.dwFlags = MOUSEEVENTF_MOVE;
						input[j++].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
						input[j].mi.dx = GetNextPar(argv[1],&i);
						if (argv[1][i] == ',')
						{
							input[j].mi.dy = GetNextPar(argv[1],&i);
							input[j++].mi.dwFlags = MOUSEEVENTF_MOVE;
							input[j++].mi.dwFlags = MOUSEEVENTF_LEFTUP;
						}
						else
							RaiseError(16);
					}
					else
						RaiseError(15);
				}
				else
					RaiseError(14);
				break;
			case 'S':
				input[j].mi.dx = (int)(GetNextPar(argv[1],&i) * vscreen_x);
				if (argv[1][i] == ',')
				{
					input[j].mi.dy = (int)(GetNextPar(argv[1],&i) * vscreen_y);
					int abso;
					switch(argv[1][i])
					{
					case ';':
						abso = 0;
						break;
					case ':':
						abso = 1;
						break;
					default:
						RaiseError(18);
					} // switch
					input[j++].mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK;
					input[j++].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
					input[j].mi.dx = GetNextPar(argv[1],&i);
					if (argv[1][i] == ',')
					{
						input[j].mi.dy = GetNextPar(argv[1],&i);
						if (abso)
						{
							input[j].mi.dx *= vscreen_x;
							input[j].mi.dy *= vscreen_y;
							input[j++].mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK;
						}
						else
							input[j++].mi.dwFlags = MOUSEEVENTF_MOVE;
						input[j++].mi.dwFlags = MOUSEEVENTF_LEFTUP;
					}
					else
						RaiseError(19);
					
				}
				else
					RaiseError(17);
				break;
			case 'w':
				input[j].mi.mouseData = GetNextPar(argv[1],&i) * WHEEL_DELTA;
				input[j++].mi.dwFlags = MOUSEEVENTF_WHEEL;
				break;
			case 'W':
				input[j++].mi.dwFlags = MOUSEEVENTF_MIDDLEDOWN;
				input[j++].mi.dwFlags = MOUSEEVENTF_MIDDLEUP;
				i++;
				break;
			case 'D':
				dbg = 1;
				i++;
				break;
			default:
				cerr << "Unrecognized mice command: '" << argv[1][i] << "'";
				RaiseError(11);
			} // switch (argv[1][i])
			if (j > 99)
				RaiseError(30);
		} // while (argv[1][i] != 0)
		if (dbg && pp)
			cout << "Prepause = " << pp << " ms\n";
		if (pp)
			Sleep(pp);
		unsigned int v, n, p, k = 0;
		b = 1;
		do
		{
			if (blocks[b][0] > 0)
			{
				n = blocks[b][0];
				p = blocks[b][1];
			}
			else
			{
				n = j; 
				p = 0;
			}
			if ((v = SendInput(n-k, &input[k], sizeof(INPUT))) == 0)
			{
				cerr << "SendInput Error: " << GetLastError;
				if (dbg)
					cout << " (n=" << n << ",k=" << k << ",p=" << p << ")";
				cout << "\n";
				RaiseError(9);
			}
			else
			{
				cout << "Sent " << v << " actions to mice.";
				if (dbg)
					cout << " (n=" << n << ",k=" << k << ",p=" << p << ")";
				cout << "\n";
			}
			k = n;
			if (p)
				Sleep(p);
		} while(blocks[b++][0] > 0);
		if (dbg)
		{
			cout << "index\tmouseData\tdwFlags\t\tdx\tdy\n";
			for (i = 0; i < j; i++)
				cout << i << "\t" << input[i].mi.mouseData << "\t\t" << FtoStr(input[i].mi.dwFlags) << "\t\t" << input[i].mi.dx << "\t" << input[i].mi.dy << "\n";
			cout << "dwFlags letters meaning:\n";
			cout << "A = MOUSEEVENTF_ABSOLUTE\n";
			cout << "M = MOUSEEVENTF_MOVE\n";
			cout << "l = MOUSEEVENTF_LEFTDOWN\n";
			cout << "L = MOUSEEVENTF_LEFTUP\n";
			cout << "r = MOUSEEVENTF_RIGHTDOWN\n";
			cout << "R = MOUSEEVENTF_RIGHTUP\n";
			cout << "c = MOUSEEVENTF_MIDDLEDOWN\n";
			cout << "C = MOUSEEVENTF_MIDDLEUP\n";
			cout << "V = MOUSEEVENTF_VIRTUALDESK\n";
			cout << "W = MOUSEEVENTF_WHEEL\n";
			cout << "x = MOUSEEVENTF_XDOWN\n";
			cout << "X = MOUSEEVENTF_XUP\n";
		}
		cout << "Program executed succesfuly.\n";
		return 0;
	} // if (argc != 2)
} // main

int GetNextPar (char *str, int *idx)
{
	int p1;
	p1 = atoi(&str[++(*idx)]);
	while ((atoi(&str[*idx]) != 0) || (str[*idx] == '0'))
		(*idx)++;
	return p1;
} // Get1Par

void RaiseError (int e)
{
	char *s;
	switch(e)
	{
	case 9:
	case 10:
	case 11:
		s = "";
		break;
	case 12:
		s = "Mice command 'm' requires 2 comma-separated parameters.";
		break;
	case 13:
		s = "Mice command 'M' requires 2 comma-separated parameters.";
		break;
	case 14:
		s = "Mice command 's' error: parameters 1 and 2 must be comma-separated.";
		break;
	case 15:
		s = "Mice command 's' error: parameters 2 and 3 must be semicolon-separated.";
		break;
	case 16:
		s = "Mice command 's' error: parameters 3 and 4 must be comma-separated.";
		break;
	case 17:
		s = "Mice command 'S' error: parameters 1 and 2 must be comma-separated.";
		break;
	case 18:
		s = "Mice command 'S' error: parameters 2 and 3 must be semicolon-separated or colon-separated.";
		break;
	case 19:
		s = "Mice command 'S' error: parameters 3 and 4 must be comma-separated.";
		break;
	case 30:
		s = "Too many mice commands, program overflow";
		break;
	case 31:
		s = "Program usage conditions have not been accepted. Please stop using the\nprogram and delete it from your Hard Drive.\n";
		break;
	default:
		s = "Unidentified Error.";
	} // switch
	cerr << s << "\n";
	exit(e);
} // RaiseError

char *FtoStr(int flags)
{
	static char sBuffer[15];
	sBuffer[0] = 0;
	int i = 0;
	if (flags & MOUSEEVENTF_ABSOLUTE)
		sBuffer[i++] = 'A';
	if (flags & MOUSEEVENTF_MOVE)
		sBuffer[i++] = 'M';
	if (flags & MOUSEEVENTF_LEFTDOWN)
		sBuffer[i++] = 'l';
	if (flags & MOUSEEVENTF_LEFTUP)
		sBuffer[i++] = 'L';
	if (flags & MOUSEEVENTF_RIGHTDOWN)
		sBuffer[i++] = 'r';
	if (flags & MOUSEEVENTF_RIGHTUP)
		sBuffer[i++] = 'R';
	if (flags & MOUSEEVENTF_MIDDLEDOWN)
		sBuffer[i++] = 'c';
	if (flags & MOUSEEVENTF_MIDDLEUP)
		sBuffer[i++] = 'C';
	if (flags & MOUSEEVENTF_VIRTUALDESK)
		sBuffer[i++] = 'V';
	if (flags & MOUSEEVENTF_WHEEL)
		sBuffer[i++] = 'W';
	if (flags & MOUSEEVENTF_XDOWN)
		sBuffer[i++] = 'x';
	if (flags & MOUSEEVENTF_XUP)
		sBuffer[i++] = 'X';
	sBuffer[i] = 0;
	return sBuffer;
} // FtoStr

bool Accepted(char *fName)
{
	fstream fin;
	char s[100];
	s[0] = 0;
	fin.open(fName,ios::in);
	if( fin.is_open() )
	{
		fin >> s;
	}
	fin.close();
	if (!strcmp(s, "ACCEPTED"))
		return true;
	else
		return false;
}
